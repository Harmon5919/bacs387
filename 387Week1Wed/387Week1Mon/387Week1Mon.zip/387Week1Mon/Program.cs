﻿using System;

namespace _387Week1Mon
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please input something:");
            string z = Console.ReadLine(); //input from user
            Console.WriteLine("Your input was " + z); //outputs to window
            Console.ReadKey(); //waits on any keystroke
        }
    }
}
